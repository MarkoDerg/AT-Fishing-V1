# lunar_fishing
Das Beste FISHING Script Auf Fivem

# Funktionen
Unterstützt ESX/QBCore

Erstelle beliebig viele Angelzonen

Angeln überall möglich

Level- und XP-System

Freelancer-Job

Bootsverleih inklusive

Unterstützung für ox_target / qtarget / qb-target

Sehr geringe Auslastung – 0.0ms im Leerlauf

Installationsdateien enthalten

# Dependencies: 
* es_extended/qb-core
* ox_lib
* ox_target/qtarget/qb-target

