import * as lib from './resource';

export * from './resource';
export * from '../shared';
export default lib;
