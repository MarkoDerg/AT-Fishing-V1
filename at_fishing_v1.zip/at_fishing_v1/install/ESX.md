1. Use OX.md if you're using ox_inventory, otherwise follow this tutorial.

2. Install these dependecies:
    ox_lib - https://github.com/overextended/ox_lib/releases/latest/download/ox_lib.zip
    ox_target/qtarget/qb-target (Optional, depends on config)

3. Ensure the resource in server.cfg

5. Copy and paste images into esx_inventoryhud/html/images (Or your inventory images folder)

6. Import this in your database:

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
    ('graphite_rod', 'Graphitrute', 350),
    ('grouper', 'Zackenbarsch', 3500),
    ('mahi_mahi', 'Goldmakrele', 3500),
    ('basic_rod', 'Angelrute', 250),
    ('haddock', 'Schellfisch', 500),
    ('artificial_bait', 'Kunstköder', 30),
    ('trout', 'Forelle', 750),
    ('red_snapper', 'Roter Schnapper', 2500),
    ('shark', 'Hai', 7500),
    ('anchovy', 'Sardelle', 20),
    ('salmon', 'Lachs', 1000),
    ('tuna', 'Thunfisch', 10000),
    ('piranha', 'Piranha', 1500),
    ('worms', 'Würmer', 10),
    ('titanium_rod', 'Titanrute', 450)
;

5. Import import.sql to your database.