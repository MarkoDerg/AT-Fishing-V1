export const checkDependency = (resource: string, minimumVersion: string, printMessage?: boolean) =>
  exports.ox_lib.checkDependency(resource, minimumVersion, printMessage);
