--- Server side so players can't dump it
SvConfig = {}

SvConfig.Webhook = 'WEBHOOK_HERE'